"use strict";

(function exposeBaoReviewSuggestion(root) {
  const HISTORY_KEY = "bao_ai_depth_history_v1";
  const ELIGIBLE_LEVELS = new Set(["hard", "expert"]);
  const MIN_DEPTH = { hard: 3, expert: 4 };
  const HISTORY_LIMIT = 10;
  const Locale = root.BaoLocale;
  const t = (english, japanese) => Locale?.t ? Locale.t(english, japanese) : english;

  function finite(value) {
    return Number.isFinite(value) ? value : null;
  }

  function eligible(level) {
    return ELIGIBLE_LEVELS.has(level);
  }

  function median(values) {
    const sorted = values.filter(Number.isFinite).slice().sort((a, b) => a - b);
    if (!sorted.length) return null;
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
  }

  function readHistory(storage, level) {
    if (!storage || !eligible(level)) return [];
    try {
      const parsed = JSON.parse(storage.getItem(HISTORY_KEY) || "{}");
      return Array.isArray(parsed[level]) ? parsed[level].filter(Number.isFinite) : [];
    } catch {
      return [];
    }
  }

  function writeHistory(storage, level, depth) {
    if (!storage || !eligible(level) || !Number.isFinite(depth)) return;
    try {
      const parsed = JSON.parse(storage.getItem(HISTORY_KEY) || "{}");
      const current = Array.isArray(parsed[level]) ? parsed[level].filter(Number.isFinite) : [];
      parsed[level] = current.concat(depth).slice(-HISTORY_LIMIT);
      storage.setItem(HISTORY_KEY, JSON.stringify(parsed));
    } catch {
      // Depth history is optional and must never interrupt the game.
    }
  }

  function countFrontPits(state, player) {
    return state?.pits?.[player]?.[0]?.filter((value) => value > 0).length || 0;
  }

  function captureOptions(engine, state) {
    try {
      return engine.legalMoves(state).filter((move) => move.type === "capture").length;
    } catch {
      return 0;
    }
  }

  function hypotheticalOpponentState(engine, state, player) {
    const copy = engine.clone(state);
    copy.player = 1 - player;
    copy.winner = null;
    copy.reason = "";
    return copy;
  }

  function addSignal(signals, type, label, weight, details = {}) {
    signals.push({ type, label, weight, ...details });
  }

  function analyze(engine, state, context, history = []) {
    const level = String(context?.ai?.level || "unknown");
    const stats = context?.ai?.stats || {};
    const depth = finite(stats.completedDepth);
    const result = {
      enabled: eligible(level),
      level,
      stats: {
        completedDepth: depth,
        elapsedMs: finite(stats.elapsedMs),
        nodes: finite(stats.nodes),
        timedOut: stats.timedOut === true,
      },
      recentMedianDepth: median(history),
      score: 0,
      recommendation: "none",
      signals: [],
    };
    if (!result.enabled) return result;

    if (result.stats.timedOut) {
      addSignal(result.signals, "timeout", "探索が時間切れになりました", 2, { value: true });
    }

    const minimum = MIN_DEPTH[level];
    if (depth !== null && depth < minimum) {
      addSignal(result.signals, "shallow-depth", `完了深度が目安の${minimum}未満でした`, 2, {
        value: depth,
        threshold: minimum,
      });
    }

    if (depth !== null && result.recentMedianDepth !== null
      && history.length >= 3 && depth <= result.recentMedianDepth - 2) {
      addSignal(result.signals, "depth-below-recent-median", "直近の探索より完了深度が大きく低下しました", 2, {
        value: depth,
        baseline: result.recentMedianDepth,
      });
    }

    try {
      const player = state.player;
      const beforeOpponent = hypotheticalOpponentState(engine, state, player);
      const beforeCaptures = captureOptions(engine, beforeOpponent);
      const applied = engine.applyMove(state, context.ai.move).state;
      const afterCaptures = captureOptions(engine, applied);
      if (afterCaptures >= beforeCaptures + 2) {
        addSignal(result.signals, "opponent-capture-options-increase", "相手の捕獲可能手が増加しました", 2, {
          before: beforeCaptures,
          after: afterCaptures,
        });
      }

      const frontBefore = countFrontPits(state, player);
      const frontAfter = countFrontPits(applied, player);
      if (frontAfter <= frontBefore - 2) {
        addSignal(result.signals, "front-occupancy-drop", "自分の前列の占有穴が大きく減少しました", 2, {
          before: frontBefore,
          after: frontAfter,
        });
      }

      if (applied.winner === 1 - player) {
        addSignal(result.signals, "immediate-loss", "この着手直後に敗北が確定しました", 4, { value: true });
      }
    } catch {
      // A failed secondary audit must not reject an otherwise legal AI move.
    }

    result.score = result.signals.reduce((sum, signal) => sum + signal.weight, 0);
    result.recommendation = result.score >= 2 ? "save" : "none";
    return result;
  }

  function formatNumber(value) {
    const locale = Locale?.isJapanese ? "ja-JP" : "en-US";
    return Number.isFinite(value) ? value.toLocaleString(locale) : "—";
  }

  function signalLabel(signal) {
    if (Locale?.isJapanese) return signal.label;
    if (signal.type === "timeout") return "The search timed out";
    if (signal.type === "shallow-depth") return `Completed depth was below the guideline of ${signal.threshold}`;
    if (signal.type === "depth-below-recent-median") return "Completed depth fell well below recent searches";
    if (signal.type === "opponent-capture-options-increase") return "The opponent gained more capture options";
    if (signal.type === "front-occupancy-drop") return "Your occupied front-row pits dropped substantially";
    if (signal.type === "immediate-loss") return "The move immediately resulted in a loss";
    return signal.label;
  }

  function render(analysis) {
    const panel = document.querySelector("#ai-review-suggestion");
    const statsNode = document.querySelector("#ai-review-stats");
    const messageNode = document.querySelector("#ai-review-message");
    const reasonsNode = document.querySelector("#ai-review-reasons");
    if (!panel || !statsNode || !messageNode || !reasonsNode) return;

    if (!analysis.enabled) {
      panel.hidden = true;
      return;
    }

    const levelName = analysis.level === "expert" ? t("Mtaalamu", "ムタアラム") : t("Hard", "むずかしい");
    statsNode.textContent = [
      t(`Difficulty: ${levelName}`, `難易度: ${levelName}`),
      t(`Completed depth: ${formatNumber(analysis.stats.completedDepth)}`, `完了深度: ${formatNumber(analysis.stats.completedDepth)}`),
      t(`Search time: ${formatNumber(analysis.stats.elapsedMs)} ms`, `探索時間: ${formatNumber(analysis.stats.elapsedMs)} ms`),
      t(`Nodes: ${formatNumber(analysis.stats.nodes)}`, `探索局面数: ${formatNumber(analysis.stats.nodes)}`),
      t(`Timed out: ${analysis.stats.timedOut ? "yes" : "no"}`, `時間切れ: ${analysis.stats.timedOut ? "あり" : "なし"}`),
    ].join(" / ");

    reasonsNode.replaceChildren();
    if (analysis.recommendation === "save") {
      messageNode.textContent = t(
        "This position is a review candidate. Recording the AI move is recommended.",
        "調査候補の局面です。AIの手の記録を推奨します。",
      );
      for (const signal of analysis.signals) {
        const item = document.createElement("li");
        item.textContent = signalLabel(signal);
        reasonsNode.append(item);
      }
      panel.dataset.recommendation = "save";
      const details = panel.closest("details");
      if (details) details.open = true;
    } else {
      messageNode.textContent = t(
        "Most recent AI search result. It did not meet the save-recommendation criteria.",
        "直前のAI探索結果です。保存推奨条件には該当しませんでした。",
      );
      panel.dataset.recommendation = "none";
    }
    panel.hidden = false;
  }

  function storageOrNull() {
    try {
      return root.localStorage;
    } catch {
      return null;
    }
  }

  function installBrowserHook() {
    const diagnostics = root.BaoDiagnostics;
    const engine = root.BaoEngine;
    if (!diagnostics || !engine || typeof document === "undefined") return;

    const originalCreateSnapshot = diagnostics.createSnapshot.bind(diagnostics);
    diagnostics.createSnapshot = (state, context = {}) => {
      const storage = storageOrNull();
      const history = readHistory(storage, context?.ai?.level);
      const analysis = analyze(engine, state, context, history);
      const snapshot = originalCreateSnapshot(state, context);
      if (analysis.enabled) {
        snapshot.review = {
          status: "unreviewed",
          recommendation: analysis.recommendation,
          score: analysis.score,
          recentMedianDepth: analysis.recentMedianDepth,
          signals: analysis.signals,
        };
        writeHistory(storage, analysis.level, analysis.stats.completedDepth);
        render(analysis);
      }
      return snapshot;
    };

    document.querySelector("#dismiss-ai-review")?.addEventListener("click", () => {
      const panel = document.querySelector("#ai-review-suggestion");
      if (panel) panel.hidden = true;
    });
  }

  const api = { HISTORY_KEY, MIN_DEPTH, eligible, median, analyze };
  root.BaoReviewSuggestion = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  installBrowserHook();
}(typeof window !== "undefined" ? window : globalThis));
